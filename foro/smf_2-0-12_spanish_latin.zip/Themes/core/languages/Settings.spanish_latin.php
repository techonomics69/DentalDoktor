<?php
// Version: 2.0 RC2; Settings

global $settings;

// Important! Before editing these language files please read the text at the top of index.english.php.
$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.gif';
$txt['theme_description'] = 'El tema por defecto de la encarnaci&oacute;n previa de SMF, de nombre clave Core.<br /><br />Autor: El Equipo de Simple Machines';

?>